package userinterfaces;


import net.thucydides.core.annotations.DefaultUrl;

import net.serenitybdd.core.pages.PageObject;

 @DefaultUrl("https:// utest.com")

public class HomePage extends PageObject {
}
